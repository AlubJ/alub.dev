﻿TtTools:

Repacking Prerequisites:
	Name the .DDS file with the final name that will be in use with TSS.
	This program will take the type before the first _ and use that as its folder in "SUPER_CHARACTER_TEXTURE"

Batch Usage:
	Drag and drop the .TEXTURE file onto the preffered .BAT file

Command Usage:
	TtTools --textureExtract [filename]
		Extract a texture from a TSS .TEXTURE file
	TtTools --textureRepack [filename]
		Repack a .DDS file and create a .TEXTURE file
	TtTools --patch [filename]
		Patches a TtGames Game that may require patching

Credits:
	Alub - TtTools
	SirYodaJedi - Batch Files